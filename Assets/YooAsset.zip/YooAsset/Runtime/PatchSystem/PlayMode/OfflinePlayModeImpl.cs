﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace YooAsset
{
	internal class OfflinePlayModeImpl : IBundleServices
	{
		internal PatchManifest AppPatchManifest;

		/// <summary>
		/// 异步初始化
		/// </summary>
		public InitializationOperation InitializeAsync()
		{
			var operation = new OfflinePlayModeInitializationOperation(this);
			OperationSystem.ProcessOperaiton(operation);
			return operation;
		}

		/// <summary>
		/// 获取资源版本号
		/// </summary>
		public int GetResourceVersion()
		{
			if (AppPatchManifest == null)
				return 0;
			return AppPatchManifest.ResourceVersion;
		}

		/// <summary>
		/// 创建解压器
		/// </summary>
		public DownloaderOperation CreateUnpackerByTags(string[] tags, int fileUpackingMaxNumber, int failedTryAgain)
		{
			List<BundleInfo> unpcakList = PatchHelper.GetUnpackListByTags(AppPatchManifest, tags);
			var operation = new DownloaderOperation(unpcakList, fileUpackingMaxNumber, failedTryAgain);
			return operation;
		}

		#region IBundleServices接口
		BundleInfo IBundleServices.GetBundleInfo(string bundleName)
		{
			if (string.IsNullOrEmpty(bundleName))
				return new BundleInfo(string.Empty);

			if (AppPatchManifest.Bundles.TryGetValue(bundleName, out PatchBundle patchBundle))
			{
				BundleInfo bundleInfo = new BundleInfo(patchBundle, BundleInfo.ELoadMode.LoadFromStreaming);
				return bundleInfo;
			}
			else
			{
				YooLogger.Warning($"Not found bundle in patch manifest : {bundleName}");
				BundleInfo bundleInfo = new BundleInfo(bundleName);
				return bundleInfo;
			}
		}
		string IBundleServices.ConvertAddress(string address)
		{
			return AppPatchManifest.ConvertAddress(address);
		}
		string IBundleServices.GetBundleName(string assetPath)
		{
			return AppPatchManifest.GetBundleName(assetPath);
		}
		string[] IBundleServices.GetAllDependencies(string assetPath)
		{
			return AppPatchManifest.GetAllDependencies(assetPath);
		}
		#endregion
	}
}