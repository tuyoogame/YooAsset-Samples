﻿
namespace YooAsset
{
	public class AddressLocationServices : ILocationServices
	{
		public string ConvertLocationToAssetPath(YooAssets.EPlayMode playMode, string location)
		{
			throw new System.NotImplementedException("该功能暂未支持！");
		}
	}
}