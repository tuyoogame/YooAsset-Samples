﻿using System.Collections;

namespace YooAsset
{
	public abstract class OperationHandleBase : IEnumerator
	{
		private readonly string _cachedAssetPath;
		internal ProviderBase _provider { private set; get; }

		internal OperationHandleBase(ProviderBase provider)
		{
			_provider = provider;
			_cachedAssetPath = provider.AssetPath;
		}
		internal abstract void InvokeCallback();

		/// <summary>
		/// 当前状态
		/// </summary>
		public EOperationStatus Status
		{
			get
			{
				if (IsValid == false)
					return EOperationStatus.None;
				if (_provider.Status == ProviderBase.EStatus.Fail)
					return EOperationStatus.Failed;
				else if (_provider.Status == ProviderBase.EStatus.Success)
					return EOperationStatus.Succeed;
				else
					return EOperationStatus.None;
			}
		}

		/// <summary>
		/// 最近的错误信息
		/// </summary>
		public string LastError
		{
			get
			{
				if (IsValid == false)
					return string.Empty;
				return _provider.LastError;
			}
		}

		/// <summary>
		/// 加载进度
		/// </summary>
		public float Progress
		{
			get
			{
				if (IsValid == false)
					return 0;
				return _provider.Progress;
			}
		}

		/// <summary>
		/// 是否加载完毕
		/// </summary>
		public bool IsDone
		{
			get
			{
				if (IsValid == false)
					return false;
				return _provider.IsDone;
			}
		}

		/// <summary>
		/// 句柄是否有效
		/// </summary>
		public bool IsValid
		{
			get
			{
				if (_provider != null && _provider.IsDestroyed == false)
				{
					return true;
				}
				else
				{
					if (_provider == null)
						YooLogger.Warning($"Operation handle is released : {_cachedAssetPath}");
					else if (_provider.IsDestroyed)
						YooLogger.Warning($"Provider is destroyed : {_cachedAssetPath}");
					return false;
				}
			}
		}

		/// <summary>
		/// 释放句柄
		/// </summary>
		internal void ReleaseInternal()
		{
			if (IsValid == false)
				return;
			_provider.ReleaseHandle(this);
			_provider = null;
		}

		#region 异步操作相关
		/// <summary>
		/// 异步操作任务
		/// </summary>
		public System.Threading.Tasks.Task Task
		{
			get { return _provider.Task; }
		}

		// 协程相关
		bool IEnumerator.MoveNext()
		{
			return !IsDone;
		}
		void IEnumerator.Reset()
		{
		}
		object IEnumerator.Current
		{
			get { return _provider; }
		}
		#endregion
	}
}