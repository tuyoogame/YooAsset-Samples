﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Reflection;

namespace YooAsset
{
	/// <summary>
	/// 程序集工具类
	/// </summary>
	internal static class AssemblyUtility
	{
		public const string YooAssetAssemblyName = "YooAsset";
		public const string YooAssetAssemblyEditorName = "YooAsset.Editor";
		public const string UnityDefaultAssemblyName = "Assembly-CSharp";
		public const string UnityDefaultAssemblyEditorName = "Assembly-CSharp-Editor";
		

		private static readonly Dictionary<string, List<Type>> _cache = new Dictionary<string, List<Type>>();

		static AssemblyUtility()
		{
			_cache.Clear();
		}

		/// <summary>
		/// 获取程序集
		/// </summary>
		public static Assembly GetAssembly(string assemblyName)
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (assembly.GetName().Name == assemblyName)
					return assembly;
			}
			return null;
		}

		/// <summary>
		/// 获取程序集里的所有类型
		/// </summary>
		private static List<Type> GetTypes(string assemblyName)
		{
			if (_cache.ContainsKey(assemblyName))
				return _cache[assemblyName];

			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (assembly.GetName().Name == assemblyName)
				{
					List<Type> types = assembly.GetTypes().ToList();
					_cache.Add(assemblyName, types);
					return types;
				}
			}

			// 注意：如果没有找到程序集返回空列表
			UnityEngine.Debug.LogWarning($"Not found assembly : {assemblyName}");
			return new List<Type>();
		}

		/// <summary>
		/// 获取带继承关系的所有类的类型
		/// <param name="parentType">父类类型</param> 
		/// </summary>
		public static List<Type> GetAssignableTypes(string assemblyName, System.Type parentType)
		{
			List<Type> result = new List<Type>();
			List<Type> cacheTypes =	GetTypes(assemblyName);
			for (int i = 0; i < cacheTypes.Count; i++)
			{
				Type type = cacheTypes[i];

				// 判断继承关系
				if (parentType.IsAssignableFrom(type))
				{
					if (type.Name == parentType.Name)
						continue;
					result.Add(type);
				}
			}
			return result;
		}

		/// <summary>
		/// 获取带属性标签的所有类的类型
		/// <param name="attributeType">属性类型</param>
		/// </summary>
		public static List<Type> GetAttributeTypes(string assemblyName, System.Type attributeType)
		{
			List<Type> result = new List<Type>();
			List<Type> cacheTypes = GetTypes(assemblyName);
			for (int i = 0; i < cacheTypes.Count; i++)
			{
				System.Type type = cacheTypes[i];

				// 判断属性标签
				if (Attribute.IsDefined(type, attributeType))
				{
					result.Add(type);	
				}
			}
			return result;
		}

		/// <summary>
		/// 获取带继承关系和属性标签的所有类的类型
		/// </summary>
		/// <param name="parentType">父类类型</param>
		/// <param name="attributeType">属性类型</param>
		public static List<Type> GetAssignableAttributeTypes(string assemblyName, System.Type parentType, System.Type attributeType, bool checkError = true)
		{
			List<Type> result = new List<Type>();
			List<Type> cacheTypes = GetTypes(assemblyName);
			for (int i = 0; i < cacheTypes.Count; i++)
			{
				Type type = cacheTypes[i];

				// 判断属性标签
				if (Attribute.IsDefined(type, attributeType))
				{
					// 判断继承关系
					if (parentType.IsAssignableFrom(type))
					{
						if (type.Name == parentType.Name)
							continue;
						result.Add(type);
					}
					else
					{
						if(checkError)
							throw new Exception($"class {type} must inherit from {parentType}.");
					}
				}
			}
			return result;
		}
	}

	/// <summary>
	/// 字符串工具类
	/// </summary>
	internal static class StringUtility
	{
		[ThreadStatic]
		private static StringBuilder _cacheBuilder = new StringBuilder(1024);

		public static string Format(string format, object arg0)
		{
			if (string.IsNullOrEmpty(format))
				throw new ArgumentNullException();

			_cacheBuilder.Length = 0;
			_cacheBuilder.AppendFormat(format, arg0);
			return _cacheBuilder.ToString();
		}
		public static string Format(string format, object arg0, object arg1)
		{
			if (string.IsNullOrEmpty(format))
				throw new ArgumentNullException();

			_cacheBuilder.Length = 0;
			_cacheBuilder.AppendFormat(format, arg0, arg1);
			return _cacheBuilder.ToString();
		}
		public static string Format(string format, object arg0, object arg1, object arg2)
		{
			if (string.IsNullOrEmpty(format))
				throw new ArgumentNullException();

			_cacheBuilder.Length = 0;
			_cacheBuilder.AppendFormat(format, arg0, arg1, arg2);
			return _cacheBuilder.ToString();
		}
		public static string Format(string format, params object[] args)
		{
			if (string.IsNullOrEmpty(format))
				throw new ArgumentNullException();

			if (args == null)
				throw new ArgumentNullException();

			_cacheBuilder.Length = 0;
			_cacheBuilder.AppendFormat(format, args);
			return _cacheBuilder.ToString();
		}

		public static List<string> StringToStringList(string str, char separator)
		{
			List<string> result = new List<string>();
			if (!String.IsNullOrEmpty(str))
			{
				string[] splits = str.Split(separator);
				foreach (string split in splits)
				{
					if (!String.IsNullOrEmpty(split))
					{
						result.Add(split);
					}
				}
			}
			return result;
		}
		public static bool StringToBool(string str)
		{
			int value = (int)Convert.ChangeType(str, typeof(int));
			return value > 0;
		}
		public static T NameToEnum<T>(string name)
		{
			if (Enum.IsDefined(typeof(T), name) == false)
			{
				throw new ArgumentException($"Enum {typeof(T)} is not defined name {name}");
			}
			return (T)Enum.Parse(typeof(T), name);
		}

		public static string RemoveFirstChar(string str)
		{
			if (string.IsNullOrEmpty(str))
				return str;
			return str.Substring(1);
		}
		public static string RemoveLastChar(string str)
		{
			if (string.IsNullOrEmpty(str))
				return str;
			return str.Substring(0, str.Length - 1);
		}
		public static string RemoveExtension(string str)
		{
			if (string.IsNullOrEmpty(str))
				return str;

			int index = str.LastIndexOf(".");
			if (index == -1)
				return str;
			else
				return str.Remove(index); //"assets/config/test.unity3d" --> "assets/config/test"
		}
	}

	/// <summary>
	/// 文件工具类
	/// </summary>
	internal static class FileUtility
	{
		/// <summary>
		/// 读取文件
		/// </summary>
		public static string ReadFile(string filePath)
		{
			if (File.Exists(filePath) == false)
				return string.Empty;
			return File.ReadAllText(filePath, Encoding.UTF8);
		}

		/// <summary>
		/// 创建文件
		/// </summary>
		public static void CreateFile(string filePath, string content)
		{
			// 删除旧文件
			if (File.Exists(filePath))
				File.Delete(filePath);

			// 创建文件夹路径
			CreateFileDirectory(filePath);

			// 创建新文件
			byte[] bytes = Encoding.UTF8.GetBytes(content);
			using (FileStream fs = File.Create(filePath))
			{
				fs.Write(bytes, 0, bytes.Length);
				fs.Flush();
				fs.Close();
			}
		}

		/// <summary>
		/// 创建文件的文件夹路径
		/// </summary>
		public static void CreateFileDirectory(string filePath)
		{
			// 获取文件的文件夹路径
			string directory = Path.GetDirectoryName(filePath);
			CreateDirectory(directory);
		}

		/// <summary>
		/// 创建文件夹路径
		/// </summary>
		public static void CreateDirectory(string directory)
		{
			// If the directory doesn't exist, create it.
			if (Directory.Exists(directory) == false)
				Directory.CreateDirectory(directory);
		}

		/// <summary>
		/// 获取文件大小（字节数）
		/// </summary>
		public static long GetFileSize(string filePath)
		{
			FileInfo fileInfo = new FileInfo(filePath);
			return fileInfo.Length;
		}
	}

	/// <summary>
	/// 哈希工具类
	/// </summary>
	internal static class HashUtility
	{
		private static string ToString(byte[] hashBytes)
		{
			string result = BitConverter.ToString(hashBytes);
			result = result.Replace("-", "");
			return result.ToLower();
		}

		#region SHA1
		/// <summary>
		/// 获取字符串的Hash值
		/// </summary>
		public static string StringSHA1(string str)
		{
			byte[] buffer = Encoding.UTF8.GetBytes(str);
			return BytesSHA1(buffer);
		}

		/// <summary>
		/// 获取文件的Hash值
		/// </summary>
		public static string FileSHA1(string filePath)
		{
			try
			{
				using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					return StreamSHA1(fs);
				}
			}
			catch (Exception e)
			{
				YooLogger.Exception(e);
				return string.Empty;
			}
		}

		/// <summary>
		/// 获取数据流的Hash值
		/// </summary>
		public static string StreamSHA1(Stream stream)
		{
			// 说明：创建的是SHA1类的实例，生成的是160位的散列码
			HashAlgorithm hash = HashAlgorithm.Create();
			byte[] hashBytes = hash.ComputeHash(stream);
			return ToString(hashBytes);
		}

		/// <summary>
		/// 获取字节数组的Hash值
		/// </summary>
		public static string BytesSHA1(byte[] buffer)
		{
			// 说明：创建的是SHA1类的实例，生成的是160位的散列码
			HashAlgorithm hash = HashAlgorithm.Create();
			byte[] hashBytes = hash.ComputeHash(buffer);
			return ToString(hashBytes);
		}
		#endregion

		#region MD5
		/// <summary>
		/// 获取字符串的MD5
		/// </summary>
		public static string StringMD5(string str)
		{
			byte[] buffer = Encoding.UTF8.GetBytes(str);
			return BytesMD5(buffer);
		}

		/// <summary>
		/// 获取文件的MD5
		/// </summary>
		public static string FileMD5(string filePath)
		{
			try
			{
				using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					return StreamMD5(fs);
				}
			}
			catch (Exception e)
			{
				YooLogger.Exception(e);
				return string.Empty;
			}
		}

		/// <summary>
		/// 获取数据流的MD5
		/// </summary>
		public static string StreamMD5(Stream stream)
		{
			MD5CryptoServiceProvider provider = new MD5CryptoServiceProvider();
			byte[] hashBytes = provider.ComputeHash(stream);
			return ToString(hashBytes);
		}

		/// <summary>
		/// 获取字节数组的MD5
		/// </summary>
		public static string BytesMD5(byte[] buffer)
		{
			MD5CryptoServiceProvider provider = new MD5CryptoServiceProvider();
			byte[] hashBytes = provider.ComputeHash(buffer);
			return ToString(hashBytes);
		}
		#endregion

		#region CRC32
		/// <summary>
		/// 获取字符串的CRC32
		/// </summary>
		public static string StringCRC32(string str)
		{
			byte[] buffer = Encoding.UTF8.GetBytes(str);
			return BytesCRC32(buffer);
		}

		/// <summary>
		/// 获取文件的CRC32
		/// </summary>
		public static string FileCRC32(string filePath)
		{
			try
			{
				using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					return StreamCRC32(fs);
				}
			}
			catch (Exception e)
			{
				YooLogger.Exception(e);
				return string.Empty;
			}
		}

		/// <summary>
		/// 获取数据流的CRC32
		/// </summary>
		public static string StreamCRC32(Stream stream)
		{
			CRC32Algorithm hash = new CRC32Algorithm();
			byte[] hashBytes = hash.ComputeHash(stream);
			return ToString(hashBytes);
		}

		/// <summary>
		/// 获取字节数组的CRC32
		/// </summary>
		public static string BytesCRC32(byte[] buffer)
		{
			CRC32Algorithm hash = new CRC32Algorithm();
			byte[] hashBytes = hash.ComputeHash(buffer);
			return ToString(hashBytes);
		}
		#endregion
	}
}