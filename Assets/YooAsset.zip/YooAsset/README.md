unity3d resources management system

https://github.com/tuyoogame/YooAsset
