# CHANGELOG

All notable changes to this package will be documented in this file.   

## [v1.0.0-preview] - 2022-04-05
*Compatible with Unity 2019.4*
