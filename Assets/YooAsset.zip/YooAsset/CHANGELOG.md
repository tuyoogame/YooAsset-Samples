# CHANGELOG

All notable changes to this package will be documented in this file.   

## [1.0.1] - 2022-04-07

### Fixed

- 修复Assets目录下存在多个YooAsset同名文件夹时，工具窗口无法显示的问题。
- 修复通过Packages导入YooAsset，工具窗口无法显示的问题。

## [1.0.0] - 2022-04-05
*Compatible with Unity 2019.4*

