# CHANGELOG

All notable changes to this package will be documented in this file.

## [1.0.7] - 2022-05-04

### Fixed

- 修复了异步操作系统的Task再次等待无效的问题。

### Changed

- YooAssets.LoadRawFileAsync()方法重新命名为YooAssets.GetRawFileAsync()
- YooAssetSetting文件夹支持了全路径搜索定位。
- 优化了打包的核心逻辑，对依赖资源进行自动划分，以及支持设置依赖资源收集器。
- 初始化的时候，删除验证失败的资源文件。
- 构建报告浏览窗口支持排序功能。
- 着色器变种收集工具支持了配置缓存。

### Added

- 支持可寻址资源定位系统，包括编辑器和运行时环境。
- 增加快速构建模式，用于EditorPlayMode完美模拟线上环境。
- 增加了Window Dock功能，已打开的界面会自动停靠在一个窗体下。
- 增加一个新的打包规则：PackTopDirectory。
- 增加获取资源信息的方法。
  ```c#
  public static AssetInfo[] GetAssetInfos(string tag)
  ```
- 增加补丁下载器下载全部资源的方法。
  ```c#
  public static PatchDownloaderOperation CreatePatchDownloader(int downloadingMaxNumber, int failedTryAgain)
  ```
- 增加指定资源版本的资源更新下载方法。
  ```c#
  public static UpdatePackageOperation UpdatePackageAsync(int resourceVersion, int timeout = 60)
  ```

### Removed

- 移除了自动释放资源的初始化参数。

## [1.0.6] - 2022-04-26

### Fixed

- 修复工具界面显示异常在Unity2021版本下。

### Changed

- 操作句柄支持错误信息查询。
- 支持UniTask异步操作库。
- 优化类型搜索方式，改为全域搜索类型。
- AssetBundleGrouper窗口添加和移除Grouper支持操作回退。

## [1.0.5] - 2022-04-22

### Fixed

- 修复了非主动收集的着色器没有打进统一的着色器资源包的问题。
- 修复了单个收集的资源对象没有设置依赖资源列表的问题。
- 修复Task异步加载一直等待的问题。

### Changed

- 资源打包的过滤文件列表增加cginc格式。
- 增加编辑器扩展的支持，第三方实现YooAsset插件。
- 优化原生文件加载逻辑，支持离线运行模式和编辑器运行模式。
- 优化场景卸载逻辑，在加载新的主场景的时候自动卸载已经加载的所有场景。
- 支持演练构建模式，在不生成资源包的情况下快速构建查看结果。
- 新增调试信息，出生场景和出生时间。

## [1.0.4] - 2022-04-18

### Fixed

- 修复资源清单附加版本之后引发的一个流程错误。
- 修复原生文件拷贝目录不存导致的加载失败。

### Changed

- 在编辑器下检测资源路径是否合法并警告。
- 完善原生文件异步加载接口。

## [1.0.3] - 2022-04-14

### Fixed

- 修复了AssetBundleDebugger窗口的BundleView视口下，Using列表显示不完整的问题。
- 修复了AssetBundleDebugger窗口的BundleView视口下，Bundle列表内元素重复的问题。
- 修复了特殊情况下依赖的资源包列表里包含主资源包的问题。

### Changed

- 实例化GameObject的时候，如果没有传递坐标和角度则使用默认值。
- 优化了资源分组配置保存策略，修改为窗口关闭时保存。
- 简化了资源版本概念，降低学习成本，统一了CDN上的目录结构。
- 资源定位接口扩展，方便开发可寻址资产定位功能。

### Added

- 离线运行模式支持WEBGL平台。
- 保留构建窗口界面的配置数据。

## [1.0.2] - 2022-04-07

### Fixed

- 修复在资源加载完成回调内释放自身资源句柄时的异常报错。
- 修复了资源分组在特殊情况下打包报错的问题。

### Changed

- StreamingAssets目录下增加了用于存放打包资源的总文件夹。

## [1.0.1] - 2022-04-07

### Fixed

- 修复Assets目录下存在多个YooAsset同名文件夹时，工具窗口无法显示的问题。
- 修复通过Packages导入YooAsset，工具窗口无法显示的问题。

## [1.0.0] - 2022-04-05
*Compatible with Unity 2019.4*

